package com.example.prol_educa.service;

public class AuthService {

	
}
