package com.example.prol_educa.utils.enuns;

public enum EEducationLevels {

	LEVEL_1
}
