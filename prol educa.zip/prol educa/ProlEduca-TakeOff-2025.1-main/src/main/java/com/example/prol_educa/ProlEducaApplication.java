package com.example.prol_educa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProlEducaApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProlEducaApplication.class, args);
	}

}
