package com.example.prol_educa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProlEducaApplicationTests {

	@Test
	void contextLoads() {
	}

}
